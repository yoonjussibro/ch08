package ch08;

public class Book3 {
    String title;
    String author;
    
    public Book3(String x, String y) {
	this.title = x;
	this.author = y;
    }
}	
